
package main

import (
	"context"
	"log"
	"time"

	proto "github.com/grpc-train-ticket/train_ticket/proto"

	"google.golang.org/grpc"
)

func main() {
	conn, err := grpc.Dial("localhost:8081", grpc.WithInsecure())
	if err != nil {
		log.Fatalf("did not connect: %v", err)
	}
	defer conn.Close()

	client := proto.NewTrainTicketServiceClient(conn)

	req := &proto.PurchaseRequest{
		From: "London",
		To:   "France",
		User: &proto.User{
			FirstName: "John",
			LastName:  "Doe",
			Email:     "john.doe@example.com",
		},
		Price: 20.0,
	}

	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()

	res, err := client.PurchaseTicket(ctx, req)
	if err != nil {
		log.Fatalf("could not purchase ticket: %v", err)
	}

	log.Printf("Response: %s, Receipt ID: %s", res.Message, res.ReceiptId)
}
