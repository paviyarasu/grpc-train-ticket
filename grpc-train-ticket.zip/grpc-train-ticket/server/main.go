
package main

import (
	"context"
	"fmt"
	"log"
	"net"
	"sync"

	proto "github.com/grpc-train-ticket/train_ticket/proto"

	"google.golang.org/grpc"
)

type server struct {
	proto.UnimplementedTrainTicketServiceServer
	mu       sync.Mutex
	receipts map[string]*proto.PurchaseResponse
	users    map[string]*proto.SeatAllocation
}

func (s *server) PurchaseTicket(ctx context.Context, req *proto.PurchaseRequest) (*proto.PurchaseResponse, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	receiptID := fmt.Sprintf("%s-%s", req.User.Email, req.From)
	response := &proto.PurchaseResponse{
		Message:   "Ticket purchased successfully!",
		ReceiptId: receiptID,
	}

	s.receipts[receiptID] = response
	seat := &proto.SeatAllocation{
		UserEmail:  req.User.Email,
		Section:    "A", // For simplicity, always assign Section A
		SeatNumber: "1",
	}
	s.users[req.User.Email] = seat

	return response, nil
}

// Implement other methods (ViewReceipt, ViewSeats, RemoveUser, ModifyUserSeat) here...

func main() {
	lis, err := net.Listen("tcp", ":8081")
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}

	s := grpc.NewServer()
	proto.RegisterTrainTicketServiceServer(s, &server{
		receipts: make(map[string]*proto.PurchaseResponse),
		users:    make(map[string]*proto.SeatAllocation),
	})

	log.Printf("Server listening on port 8081...")
	if err := s.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}
}
